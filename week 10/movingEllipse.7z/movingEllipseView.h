
// movingEllipseView.h : CmovingEllipseView ���O������
//

#pragma once


class CmovingEllipseView : public CView
{
protected: // �ȱq�ǦC�ƫإ�
	CmovingEllipseView();
	DECLARE_DYNCREATE(CmovingEllipseView)
private:
	int m_x, m_y;
// �ݩ�
public:
	CmovingEllipseDoc* GetDocument() const;

// �@�~
public:

// �мg
public:
	virtual void OnDraw(CDC* pDC);  // �мg�H�yø���˵�
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// �{���X��@
public:
	virtual ~CmovingEllipseView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ͪ��T�������禡
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};

#ifndef _DEBUG  // movingEllipseView.cpp ������������
inline CmovingEllipseDoc* CmovingEllipseView::GetDocument() const
   { return reinterpret_cast<CmovingEllipseDoc*>(m_pDocument); }
#endif

